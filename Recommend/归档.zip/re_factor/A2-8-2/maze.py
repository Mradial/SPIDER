import random
import pygame

# 矩阵颜色的对应值
FLOOR = 0
WALL  = 1
PATH  = 2
REPETITION = 3
EXIT = 4
SOLUTION = 5


# 迷宫背景颜色 --> 白色
FLOOR_COLOUR = (255,255,255)
# 迷宫墙壁 --> 黑色
WALL_COLOUR = (0,0,0)
# 迷宫路径颜色 --> 绿色
PATH_COLOUR = (0,255,0)
# 迷宫解法路径颜色  --> 红色
SOLVER_COLOUR = (255,0,0)
# 走过两次的路径
REPETITION_COLOR = (0,0,255)
# 出口为金色
EXIT_COLOR = (255,251,0)
# 最后的通路颜色--->黄色
SOLUTION_COLOR = (0,255,255)

# [背景、墙壁、行走路径]
MAZE_COLOURS = [FLOOR_COLOUR, WALL_COLOUR, PATH_COLOUR, REPETITION_COLOR, EXIT_COLOR, SOLUTION_COLOR]

# 生成迷宫矩阵
def mazeArray(value, width, height):
    return [[value]*height for i in range(width)]

# 返回4值元组
def cellRect(x, y, tile_size):
    return (x*tile_size, y*tile_size, tile_size, tile_size)


class Maze():

    """ 随机迷宫生成 """

    def __init__(self,tile_size, screen):
        """ 迷宫构造函数 
        """
        self.width = 20
        self.height = 20
        self.tile_size = tile_size
        # 列表初始化函数
        WALL =  1
        self.layout = mazeArray(WALL, self.width, self.height)
        FLOOR = 0
        self.visited = mazeArray(FLOOR,self.width, self.height)
        # 绘制屏幕
        self.screen = screen
        self.neighbours = []
        self.stack = []
        self.x = 0
        self.y = 0
        self.generate()
        self.maze = self.maze_layout()
        

    def Regenerate(self):
        """  内部初始化变量 
        """
        self.__init__(self.width, self.height, self.tile_size, self.screen)
    
    def ClearPath(self):
        """ 清除路径
        """
        for i in range(self.width):
            for j in range(self.height):
                # PATH = 2 -->  FLOOR = 0
                # 数值替换即颜色替换
                if self.layout[i][j] in (PATH, REPETITION):
                    self.layout[i][j] = FLOOR
    
    def draw_self(self):
        """ 绘制迷宫本身 
        """
        for i in range(self.width):
            for j in range(self.height):
                # 循环提取矩阵cell值
                cell_type = self.layout[i][j]
                # 绘制对应的颜色
                self.screen.fill(MAZE_COLOURS[cell_type], cellRect(i, j, self.tile_size))
         
    def generate(self):
        """ 生成主循环函数 """
        while not self._generate_step():
            pass
        # 执行结束
        self.status = False
   
    def _generate_step(self):
        """ 迷宫生成主体函数 
        """
        # 从迷宫的墙中获得一个格子，把它设置到迷宫中
        self.layout[self.x][self.y] = FLOOR
        # 设置迷宫出口
        self.layout[self.width-2][self.height-2] = EXIT
        #把当前位置标记为已经访问
        
        self.visited[self.x][self.y] = True
        self.neighbours = [] #Reset neighbours

        #寻找没有初始化过的迷宫道路
        
        # 向上探索，有没有未被初始化的迷宫路面
        if (self.y-2) >= 0:
            if not self.visited[self.x][self.y-2]: 
                self.neighbours.append((self.x,self.y-2))
        # 向左探索
        if (self.x-2) >= 0:
            if not self.visited[self.x-2][self.y]: 
                self.neighbours.append((self.x-2,self.y))
        # 向右探索
        if (self.x+2) < self.width:
            if not self.visited[self.x+2][self.y]: 
                self.neighbours.append((self.x+2,self.y))
        # 向下探索
        if (self.y+2) < self.height:
            if not self.visited[self.x][self.y+2]: 
                self.neighbours.append((self.x,self.y+2))

        if self.neighbours:
            # print(self.neighbours)
            #随机从相邻块列表中选择一个格子
            newCell = random.choice(self.neighbours)
            #Add current cell to the stack
            # 将当前的位置存储在列表中
            self.stack.append((self.x,self.y))

            #Remove the wall between current and chosen cell
            # 选择随机选中的cell
            new_x, new_y = newCell

            #Cell is above
            if new_x == self.x and (new_y+2) == self.y:
                self.layout[new_x][new_y+1] = FLOOR
            #Cell is below
            elif new_x == self.x and (new_y-2) == self.y:
                self.layout[new_x][new_y-1] = FLOOR
            #Cell is left
            elif (new_x+2) == self.x and new_y == self.y:
                self.layout[new_x+1][new_y] = FLOOR
            #Cell is right
            elif (new_x-2) == self.x and new_y == self.y:
                self.layout[new_x-1][new_y] = FLOOR

            self.x = new_x
            self.y = new_y
        else: #Cell has no neighbours
            if self.stack:
                #Go back to the previous current cell
                self.x, self.y = self.stack.pop()

            if not self.stack:
                #Generation has finished
                return True

    def maze_layout(self):
        """ 给矩阵加边
        """
        maze = self.layout
        maze.insert(0,[1 for i in range(self.width)])
        med_pool = []
        for row in maze:
            row.insert(0,1)
            med_pool.append(row)
        return med_pool

    def draw_maze(self,screen):
        """ 绘制迷宫本身 
        """
        for i in range(self.width):
            for j in range(self.height):
                # 循环提取矩阵cell值
                cell_type = self.maze[i][j]
                # 绘制对应的颜色

                screen.fill(MAZE_COLOURS[cell_type], cellRect(i, j, self.tile_size))