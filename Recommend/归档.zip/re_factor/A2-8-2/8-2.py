import pygame 
import  maze
import sys
import central_
import  copy 

width_cells = 21
height_cells = 21
tile_size = 10


# 初始化设置
pygame.init()


fclock =  pygame.time.Clock()

""" 屏幕创建及 """
# 创建主屏幕
screen = pygame.display.set_mode((800,600))

map_screen= pygame.surface.Surface((width_cells*tile_size, height_cells*tile_size))
main_screen = pygame.surface.Surface((600,600))

# 设置标题 
pygame.display.set_caption('Maze_Path')

""" 生成迷宫,控制中心,玩家, 动态绘制类 """
# 生成新的迷宫 绘制也是这里面
new_maze = maze.Maze(tile_size, map_screen)

layout_one = copy.deepcopy(new_maze.layout)
layout_two = copy.deepcopy(new_maze.layout)


# 创建控制中心
control = central_.Center(new_maze.layout,tile_size)
player =  central_.Player()

# 创建内部类
draw_maze = central_.CreateMaze(layout_two,tile_size,main_screen)
draw_maze.build_topology()

now_position = [1,1]

# 初始方向
direction = 1

maze = copy.deepcopy(new_maze.layout)
layout = copy.deepcopy(new_maze.layout)
tool = central_.Maze_tool(21)

stack_position = [1,1] 
stack = []
def maze_solve(position,layout):
    global stack
    global stack_position
    
    neighbours = []
    if layout[position[0]][position[1]] == 0:
        layout[position[0]][position[1]] = 2
    elif layout[position[0]][position[1]] == 4:
        return "END"
    neighbours = tool.find_neighbours(position,layout)
    if neighbours:
        new_position = neighbours[0]
        stack.append(position)
        position = new_position
    else:
        if stack:
            position = stack.pop() 
    stack_position =  position

while True:
    
    # 时间推出
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                m = now_position[0] + 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m,n]

                control.change_direction("右")
            if event.key == pygame.K_LEFT:
                m = now_position[0] - 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m,n]

                control.change_direction("左")
            if event.key == pygame.K_UP:
                m = now_position[0]
                n = now_position[1] - 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m,n]

                control.change_direction("上")
            if event.key == pygame.K_DOWN:
                m = now_position[0]
                n = now_position[1] + 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m,n]

                control.change_direction("下")
            
            # 控制移动
            control.control_rect()
            # draw_maze.draw_neighbor(main_screen,control.map_position,tile_size)
            
    
    # 寻找解法
    """ 寻找最终的路径 """
    maze_solve(stack_position,layout)

    # 绘制背景
    screen.fill((0,0,0))
    # 游戏角色切换造型
    player.move(control.direction,main_screen)

    # 绘制迷宫地图啊 
    control.draw_map_maze(stack,map_screen)
    
    # 实际场景绘制
    draw_maze.draw_neighbor(now_position)
    
    # 绘制角色
    main_screen.blit(player.image,player.rect)
 
    
    screen.blit(map_screen,(590,0))
    screen.blit(main_screen,(-10,0))
    # 显示游戏结果信息
    control.show_info(screen)
    
    pygame.display.update()
    fclock.tick(5)