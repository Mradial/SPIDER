import pygame 
import  maze
import sys
import central_
import  copy 

width_cells = 21
height_cells = 21
tile_size = 10

# 初始化设置
pygame.init()

 
# 图片加载
happy = pygame.image.load('media/image/happy.png')

fclock =  pygame.time.Clock()

""" 屏幕创建及 """
# 创建主屏幕
screen = pygame.display.set_mode((800,600))
map_screen= pygame.surface.Surface((width_cells*tile_size, height_cells*tile_size))
main_screen = pygame.surface.Surface((600,600))

# 设置标题 
pygame.display.set_caption('Maze_Path')

""" 生成迷宫,控制中心,玩家, 动态绘制类 """
# 生成新的迷宫 绘制也是这里面
new_maze = maze.Maze(tile_size, map_screen)
layout_one = copy.deepcopy(new_maze.layout)
layout_two = copy.deepcopy(new_maze.layout)

# 创建控制中心
control = central_.Center(new_maze.layout,tile_size)
player = central_.Player()

# 创建绘制类
draw_maze = central_.CreateMaze(layout_two,tile_size,main_screen) 
draw_maze.build_topology()

# 初始方向
direction = 1

# 创建迷宫
maze = copy.deepcopy(new_maze.layout)


now_position = [1, 1]

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

        ''' 作业代码 '''

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                m = now_position[0] + 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_LEFT:
                m = now_position[0] - 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_UP:
                m = now_position[0]
                n = now_position[1] - 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_DOWN:
                m = now_position[0]
                n = now_position[1] + 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]


        # 控制人物朝向
        if event.type == pygame.KEYDOWN:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    control.change_direction("右")
                    control.control_rect(now_position)

                if event.key == pygame.K_LEFT:
                    control.change_direction("左")
                    control.control_rect(now_position)

                if event.key == pygame.K_UP:
                    control.change_direction("上")
                    control.control_rect(now_position)

                if event.key == pygame.K_DOWN:
                    control.change_direction("下")
                    control.control_rect(now_position)


            # now_position = control_pos(speed,layout,now_position)
            # draw_maze.draw_neighbor(main_screen,control.map_position,tile_size)
            
    
    # 绘制背景
    screen.fill((0, 0, 0))

    # 绘制迷宫地图
    screen.blit(map_screen,(590,0))

    # pygame.transform.rotozoom(main_screen,0,0.5)
    
    screen.blit(main_screen,(-10,0))

    control.draw_map_maze(map_screen)

    draw_maze.draw_neighbor(now_position)

    draw_maze.draw_key(control.key_positions,now_position)

    # 绘制角色
    player.move(control.direction, main_screen)
    main_screen.blit(player.image,player.rect)

    # 显示游戏结果信息
    # control.show_info(screen)

    if not control.game_status:
        screen.fill((255,255,255))
        screen.blit(happy,(100,100))
    # 刷新屏幕
    
    pygame.display.update()
    pygame.transform.rotozoom(main_screen,90,0.5)
    fclock.tick(30)