import pygame
import random
import sys
 
FLOOR = 0 
EXIT = 4



""" 全局变量 """
FLOOR_COLOUR = (255,255,255)
WALL_COLOUR = (0,0,0)
PATH_COLOUR = (0,255,0)
SOLVER_COLOUR = (255,0,0)
REPETITION_COLOR = (0,0,255)
EXIT_COLOR = (255,251,0)
# 最后的通路颜色--->黄色
SOLUTION_COLOR = (0,255,255)

MAZE_COLOURS = [FLOOR_COLOUR, WALL_COLOUR, PATH_COLOUR, REPETITION_COLOR, EXIT_COLOR, SOLUTION_COLOR]


""" 游戏的控制中枢 """

# 所有的执行指令都是从这里发射出去的
pygame.init()

# 资源加载
apple = pygame.image.load("media/image/path.png")
boom = pygame.image.load("media/image/wall.png")
peach = pygame.image.load("media/image/peach.png")
# 字体加载
font = pygame.font.Font('./font/HanyiSentyCrayon.ttf', 80)


class Player():
    
    """ 玩家造型切换 """

    def __init__(self):
        """ 玩家构造函数 
        """
        self.rightimage = [pygame.image.load("media/player/links_01.png"),pygame.image.load("media/player/links_02.gif"),pygame.image.load("media/player/links_03.gif"),pygame.image.load("media/player/links_04.gif"),pygame.image.load("media/player/links_05.gif"),pygame.image.load("media/player/links_06.gif"),pygame.image.load("media/player/links_07.gif"),pygame.image.load("media/player/links_08.gif")]
        self.downimage = [pygame.image.load("media/player/links_09.gif"),pygame.image.load("media/player/links_10.gif"),pygame.image.load("media/player/links_11.gif"),pygame.image.load("media/player/links_12.gif"),pygame.image.load("media/player/links_13.gif"),pygame.image.load("media/player/links_14.gif"),pygame.image.load("media/player/links_15.gif"),pygame.image.load("media/player/links_16.gif")]
        self.leftimage = [pygame.image.load("media/player/links_17.gif"),pygame.image.load("media/player/links_18.gif"),pygame.image.load("media/player/links_19.gif"),pygame.image.load("media/player/links_20.gif"),pygame.image.load("media/player/links_21.gif"),pygame.image.load("media/player/links_22.gif"),pygame.image.load("media/player/links_23.gif"),pygame.image.load("media/player/links_24.gif")]
        self.upimage = [pygame.image.load("media/player/links_25.gif"),pygame.image.load("media/player/links_26.gif"),pygame.image.load("media/player/links_27.gif"),pygame.image.load("media/player/links_28.gif"),pygame.image.load("media/player/links_29.gif"),pygame.image.load("media/player/links_30.gif"),pygame.image.load("media/player/links_31.gif"),pygame.image.load("media/player/links_32.gif")]
        self.image = pygame.image.load("media/player/links_01.png")
        self.rect = self.image.get_rect()
        self.rect.center = [300, 300]
        self.flag = 0

    def move(self,direction,screen):
        """ 角色移动控制
        """
        self.flag += 1
        flag = self.flag%8
        # move the skier right and left
        if direction == 1:
            self.image = self.rightimage[flag]
        elif direction == 2:
            self.image = self.downimage[flag]
        elif direction == 3:
            self.image = self.leftimage[flag]
        else:
            self.image = self.upimage[flag]
        # 角色屏幕绘制
        screen.blit(self.image,self.rect)


class Center():

    """ 迷宫控制核心 """

    def __init__(self,maze,tile_size):
        # 初始化传入生成好的迷宫矩阵
        self.maze = maze
        self.size = len(maze)
        # tile_size
        self.tile_size = tile_size
        # 记录按键事件（之前与现在）
        self.key = None
        # map 位置 
        self.map_position = [tile_size,tile_size]
        self.map_rect = pygame.Rect(tile_size,tile_size,self.tile_size,self.tile_size)
        # 真实位置 
        # self.real_position = [0,0]
        # self.real_rect = pygame.Rect(-300,-300,10,10)
        # 获取迷宫的死胡同点
        self.blind_alley_positions = self.get_blind_alley_positions()
        # 钥匙埋藏点
        self.key_positions = []
        # 收集的钥匙数量 
        self.key_number = 0
        # 游戏运行状态
        self.font = font
        self.game_status = True
        # 走过的路径
        self.path = [[tile_size,tile_size]]
        self.real_path = 1
        # 游戏通关耗时
        self.time = 0
      
    def control_rect(self,speed):
        """
        控制小地图上的角色移动
        - 输入: speed 
        - 输出: 更改对应属性:
        """
        speed = [speed[0]*self.tile_size,speed[1]*self.tile_size]
        m =  int((self.map_position[0] + speed[0])/self.tile_size)
        n =  int((self.map_position[1] + speed[1])/self.tile_size)
        # 进入核心判断
        if int(self.maze[m][n]) == 1:
            # 在此不做任何改变
            pass
        else:
            # 判断刷新之后得的位置
            # self.map_position = [self.map_position[0]+speed[0],self.map_position[1]+speed[1]]
            self.map_position = [m*self.tile_size,n*self.tile_size]
            self.map_rect =  pygame.Rect(self.map_position[0],self.map_position[1],self.tile_size,self.tile_size)
              
    def move(self,speed):
        """ 移动判断集合 """
        self.control_rect(speed)
        
    def get_blind_alley_positions(self):
        """ 获取迷宫死胡同点
        """
        blind_alley_positions = []
        for m,n in  enumerate(self.maze):
            for x,y in enumerate(n):
                # 生成迷宫右下边为1
                if m < self.size-1 and x < self.size-1 and m > 0 and x > 0 :
                    res = sum([self.maze[m+1][x],self.maze[m-1][x],self.maze[m][x-1],self.maze[m][x+1]])
                    # 死胡同判断
                    if y == 0 and res == 3 :
                        if  m == 1 and x == 1:
                            pass
                        else:
                            blind_alley_positions.append([m*self.tile_size,x*self.tile_size])
        return blind_alley_positions

    def draw_key(self,screen):
        """ 随机选取死胡同点放置"三个Key"
        - 随机选取三死胡同点藏Key,并在小地图上绘制对应的点
        - 输入:绘制的屏幕
        """
        #  选取藏钥匙的地点
        if len(self.key_positions) == 0 and self.key_number == 0:
            key_positions = []
            for i in range(3):
            # while len(self.key_positions) < 4:
                key = random.choice(self.blind_alley_positions)
                key_positions.append(key)
                self.blind_alley_positions.remove(key)
            self.key_positions = key_positions
        # 在对应的位置进行绘制
        if len(self.key_positions) != 0:
            for x in self.key_positions:
                # 钥匙绘制
                pygame.draw.rect(screen,(255,0,100),pygame.Rect(x[0],x[1],self.tile_size,self.tile_size))
        
        # 判断自己是否走到这个位置上,如果在收集成功
        if self.map_position in self.key_positions:
            self.key_number += 1
            self.key_positions.remove(self.map_position)
    
    def pass_game(self):
        """ 判断游戏是否通关 
        - 钥匙数量收集完成后且位置位于终点坐标 --> 游戏过关
        - 输出: bool值
        """
        if self.map_position == [(self.size-2)*self.tile_size,((self.size-2))*self.tile_size] and  self.key_number == 3:
            get_time = pygame.time.get_ticks()//1000
            self.game_status = False
            
    def show_info(self,screen):
        """ 绘制游戏通关时间,走的步数
        -  绘制到对应的区域
        """
        if self.game_status:
            self.time = pygame.time.get_ticks()//1000
        # 游戏概况
        time_bar = self.font.render("用时:"+str(self.time), True,(255,255,0))
        step_bar = self.font.render("步数:" + str(self.real_path), True,(255,255,0))
        real_step = self.font.render("实际:" + str(len(self.path)), True,(255,255,0))
        # 游戏信息绘制
        screen.blit(time_bar,(600,250))
        screen.blit(step_bar,(600,300))
        screen.blit(real_step,(600,350))

    def draw_path(self,screen):
        """ 绘制行走的路线
        - 绘制路线
        """
        if self.map_position != self.path[-1]:
            self.real_path += 1
            if self.map_position not in self.path:
                self.path.append(self.map_position)
            else:
                self.path.pop()
        # 进行路径绘制
        for  i in self.path:
            pygame.draw.rect(screen,(0,100,0),pygame.Rect(i[0],i[1],self.tile_size,self.tile_size))  

    def draw_fal_path(self,path,screen):
        """ 绘制深度优先的路径
        ——  最终的路径绘制
        """
        # 进行路径绘制
        for  i in path:
            pygame.draw.rect(screen,(255,128,128),pygame.Rect(i[0]*self.tile_size,i[1]*self.tile_size,self.tile_size,self.tile_size)) 

    def draw_map_maze(self,screen):
        """ 绘制迷宫本身
        """
        for i in range(self.size):
            for j in range(self.size):
                # 循环提取矩阵cell值
                cell_type = self.maze[i][j]
                # 绘制对应的颜色
                screen.fill(MAZE_COLOURS[cell_type], pygame.Rect(i*self.tile_size, j*self.tile_size, self.tile_size,self.tile_size))
        # 绘制方块
        pygame.draw.rect(screen,(0,255,0),self.map_rect)
        # 绘制钥匙
        self.draw_key(screen)
        # 判断游戏是否过关
        self.pass_game()
        # 绘制最终的路径
        # self.draw_fal_path(stack,screen)
        self.draw_path(screen)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            pass 
        else:
            screen.fill((0,0,0))


class  Cell():

    """ 真实位置的绘图单元 """

    def __init__(self,id,image):
        """ 绘制单元的构造函数
        """
        # 主键
        self.id = id
        # cell 文件属性 
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (0,0)
        # 维护自身的拓扑关系图
        self.right = None
        self.right_up = None
        self.up = None
        self.left_up = None
        self.left = None
        self.left_down = None
        self.down = None
        self.right_down = None
    
    def set_image(self,image):
        """ 设置cell的图片属性
        """
        self.image = image 

    def set_neighbor(self,neighbor_pool):
        """ 设置自己邻近cell (逆时针旋转)
        """
        self.right = neighbor_pool[0]
        self.right_up = neighbor_pool[1]
        self.up = neighbor_pool[2]
        self.left_up = neighbor_pool[3]
        self.left = neighbor_pool[4]
        self.left_down = neighbor_pool[5]
        self.down = neighbor_pool[6]
        self.right_down = neighbor_pool[7]

    def get_neighbor(self):
        """  返回自己的邻近cell （共计8个元素）
        """
        cells = [self.left_up,self.up,self.right_up,
                self.left,self.right,
                self.left_down,self.down,self.right_down]
        return cells 

    def set_image_rect(self,pos_):
        """  设置图片的Rect.center
        """
        self.rect.center = pos_


class CreateMaze():

    """ 真实的迷宫绘制  """

    def __init__(self,layout,size):
        """ 迷宫构造函数绘制方式
        """
        # 迷宫矩阵
        self.maze = layout
        self.new_maze = []
        # 原始迷宫尺寸
        self.size = len(layout)
        # 基础素材列表
        self.atom_pool = [apple,boom,peach]

    def add_zero(self):
        """ 原始迷宫双边加零 + 实例化
        """ 
        lake = self.maze
        # 上下加边
        lake.insert(0,[2 for i in range(self.size+1)])
        lake.append([2 for i in range(self.size+1)])
        # 循环首尾加减
        sea = []
        for row in lake:
            row.insert(0,2)
            row.append(2)
            sea.append(row)
        self.new_maze = sea

    def build_topology(self):
        """构建拓扑关系
        - 矩阵颜色的对应值
        """
        # 加零操作
        self.add_zero()
        
        # 列表存储实例化对象
        maze_obj = []
        for x in self.new_maze:
            pool = []
            for y in x:
                if y == 1 or y == 2:
                    # 墙
                    cell = Cell(y,self.atom_pool[1])
                elif y == 0:
                    # 路径
                    cell = Cell(y,self.atom_pool[0])
                elif y == 4:
                    cell = Cell(y,self.atom_pool[2])
                else:
                    cell = Cell(y,self.atom_pool[2])
                pool.append(cell)
            maze_obj.append(pool)
        self.new_maze = maze_obj
        # 构建拓扑关系
        for m,n in enumerate(self.new_maze):
            # 下边框不构建
            for x,y in enumerate(n):
                    # 上 左边框不构建
                if y.id != -1:
                    try:
                        # 拓扑关系开始建立
                        pool = [
                            self.new_maze[m][x+1],
                            self.new_maze[m-1][x+1],
                            self.new_maze[m-1][x],
                            self.new_maze[m-1][x-1],
                            self.new_maze[m][x-1],
                            self.new_maze[m+1][x-1],
                            self.new_maze[m+1][x],
                            self.new_maze[m+1][x+1],
                        ]
                        y.set_neighbor(pool)
                    except IndexError :
                        pass     

    def draw_neighbor(self,screen,map_position,tile_size,key_positions):
        """ 根据坐标判断邻居元素 并进行绘制 
        """
        map_position = [map_position[0]*10,map_position[1]*10]
        x,y = int(map_position[0]/10)+1,int(map_position[1]/10)+1
        # 找到对应元素的位置  
        cell = self.new_maze[x][y]
        cells_pool  = [
                        [cell.left_up.left_up,cell.left_up.up,cell.up.up,cell.right_up.up,cell.right_up.right_up],
                        [cell.left_up.left,cell.left_up,cell.up,cell.right_up,cell.right_up.right],
                        [cell.left,cell.left,cell,cell.right,cell.right.right],
                        [cell.left_down.left,cell.left_down,cell.down,cell.right_down,cell.right_down.right],
                        [cell.left_down.left_down,cell.left_down.down,cell.down.down,cell.right_down.down,cell.right_down]]
        
        # 设置绘制位置,然后接着绘制
        screen.fill((255,255,255))
        for m,n in enumerate(cells_pool):
            e = m * 120 + 60
            for x,y in enumerate(n):
                f =x * 120 + 60
                y.set_image_rect((e,f))
                screen.blit(y.image,y.rect)
        
        ''' 内部函数调用 '''
        # 绘制KEY
        self.draw_key(key_positions,map_position,screen)
        
    def draw_key(self,key_positions,map_position,screen):
        """ 在实景中绘制真的Key图案
        - 判断为key位置是否可以绘制的问题
        - 输入: map_position,key_positions
        """
        if len(key_positions) != 0 :
            # 钥匙坑位置存在时，才判断是否绘制
            for i in key_positions:
                if  abs(map_position[0]-i[0]) <= 20 and abs(map_position[1]-i[1]) <= 20:
                    x = 300 - (map_position[0]-i[0]) * 12
                    y = 300 - (map_position[1]-i[1]) * 12
                    # 图形绘制问题的哈
                    rect = pygame.Rect(x,y,40,40)
                    rect.center = (x,y) 
                    pygame.draw.rect(screen,(255,0,100),rect)


class Node():
    
    def __init__(self,pos):
        # 自身节点位置
        self.pos = pos
        # self.pos_pool = pos_pool
        # 节点信息
        self.before_node = []
        self.after_node = []
        # 与后置节点连接的路径中是否有重点
        self.status = None
    
    # 设置节点
    def set_before_node(self,node,t_f):
        if node not in self.before_node:
            self.before_node.append(node)
            self.status = t_f
        else:
            print("before")
    
    def set_after_node(self,node):
        if node not in self.after_node:
            self.after_node.append(node)
        else:
            print("after")

    def rm_after_node(self):
        """删除after_node中的第一个node
        - 如果after_node 存在的话,删除第一个Node
        """
        if self.after_node:
            del  self.after_node[0]
        

class Solve():

    def __init__(self,maze,tile_size,length):
        self.maze = maze
        self.tile_size = tile_size
        self.length =  length
        # 加边迷宫
        self.med_maze = self.create_med_maze()
        # 获取死胡同点
        self.blind_alley_positions = self.get_blind_alley_positions()
        # 获取路口转折点
        self.crossroads_positions = self.get_crossroads_positions()
        # 节点之间的信息
        self.links = []
        # 暂存的点（已经在剪枝操作过程中被处理的点）
        self.med_positions = self.blind_alley_positions
        # 最终储存维护的path_tree
        self.path_tree = dict()
        # find_links 过程中的死胡同点
        self.med_blind_alley_positions = self.blind_alley_positions
        self.med_crossroads_positions = self.crossroads_positions
        #  node_stack and med_node_pos and  lost_node
        self.node_stack =  []
        self.med_node_pos = [] 
        self.lost_node = []
    
    def create_med_maze(self):
        """ 创建加边的迷宫
        - up,left 加1
        """
        maze = self.maze
        maze.insert(0,[1 for i in range(self.length)])
        lake = []
        for row in maze:
            row.insert(0,1)
            lake.append(row)
        lake[self.length-1][self.length-1] = 0
        return lake

    def  get_crossroads_positions(self):
        """ 寻找路口
        - 寻找所有的路口
        - 输入 : 迷宫所有的路径
        - 输出 : 路口列表 
        """
        crossrads_positions = []
        for m,n in enumerate(self.med_maze):
            for x,y in enumerate(n):
                # 生成迷宫右下边为1
                if m < self.length and x < self.length and m > 0 and x > 0 :
                    res = sum([self.med_maze[m+1][x],self.med_maze[m-1][x],self.med_maze[m][x-1],self.med_maze[m][x+1]])
                    # 死胡同判断
                    if y == 0 and res < 2 :
                        # print(self.med_maze[11][0],self.med_maze[11][2],self.med_maze[10][1],self.med_maze[12][1])
                        # print(m,x)
                        # print([m*self.tile_size,x*self.tile_size],[self.med_maze[m+1][x],self.med_maze[m-1][x],self.med_maze[m][x-1],self.med_maze[m][x+1]])
                        # crossrads_positions.append([(m-1)*self.tile_size,(x-1)*self.tile_size])
                        crossrads_positions.append([m*self.tile_size,x*self.tile_size])
        return crossrads_positions
                 
    def get_blind_alley_positions(self):
        """ 获取迷宫死胡同点
        - maze_layout 获取迷宫的死胡同点
        - self.blind_alley_positions
        """
        blind_alley_positions = []
        for m,n in  enumerate(self.med_maze):
            for x,y in enumerate(n):
                # 生成迷宫右下边为1
                if m < self.length and x < self.length and m > 0 and x > 0 :
                    res = sum([self.med_maze[m+1][x],self.med_maze[m-1][x],self.med_maze[m][x-1],self.med_maze[m][x+1]])
                    # 死胡同判断
                    if y == 0 and res == 3 :
                        if  m == 1 and x == 1:
                            pass
                        # blind_alley_positions.append([(m-1)*self.tile_size,(x-1)*self.tile_size])
                        else:
                            blind_alley_positions.append([m*self.tile_size,x*self.tile_size])
        return blind_alley_positions
    
    def find_way_out(self,position):
        """ 寻找死胡同到路口的路径(剪枝操作) --> 复用
        - 输入:死胡同
        - 输出:死胡同到路口的路径
        """
        # 生成初始列表 
        path_positions = [position]
        status = True
        while status:
            x = int(path_positions[-1][0]/self.tile_size)
            y = int(path_positions[-1][1]/self.tile_size)
            """ 判断下一步迈向哪里 """ 
            if  x < self.length and y < self.length and x > 0 and y > 0:
                # print(path_positions)
                # print(x,y)
                # print("下,上,右,左:",self.med_maze[x+1][y]==0,self.med_maze[x-1][y]==0,self.med_maze[x][y+1]==0,self.med_maze[x][y-1]==0)
                if self.med_maze[x+1][y] == 0 and [(x+1)*self.tile_size,y*self.tile_size] not in path_positions and [(x+1)*self.tile_size,y*self.tile_size] not in self.med_positions:
                    pos = [(x+1)*self.tile_size,y*self.tile_size]
                    path_positions.append(pos)
                    # print("x+1")
                    if  pos in self.med_crossroads_positions or pos == [10,10]:
                        status = False
                elif self.med_maze[x-1][y] == 0 and [(x-1)*self.tile_size,y*self.tile_size] not in path_positions and [(x-1)*self.tile_size,y*self.tile_size] not in self.med_positions:
                    pos = [(x-1)*self.tile_size,y*self.tile_size]
                    path_positions.append(pos)
                    # print("x-1")
                    if  pos in self.med_crossroads_positions or pos == [10,10]:
                        status = False
                elif self.med_maze[x][y+1] == 0 and [x*self.tile_size,(y+1)*self.tile_size] not in path_positions and [x*self.tile_size,(y+1)*self.tile_size] not in self.med_positions:
                    pos = [x*self.tile_size,(y+1)*self.tile_size]
                    path_positions.append(pos)
                    # print("y+1")
                    if  pos in self.med_crossroads_positions or pos == [10,10]:
                        status = False
                elif self.med_maze[x][y-1] == 0 and [x*self.tile_size,(y-1)*self.tile_size] not in path_positions and [x*self.tile_size,(y-1)*self.tile_size] not in self.med_positions:
                    # 测试
                    pos = [x*self.tile_size,(y-1)*self.tile_size]
                    path_positions.append(pos)
                    # print("y-1")
                    if  pos in self.med_crossroads_positions or pos == [10,10]:
                        status = False   
        return  path_positions              
    
    def find_links(self):
        """ 计算路口与死胡同之间的路径,并建立各节点之间的关系
        - todo: 寻找树梢到树杈的连接,判断最新添加的树杈点是否变成树梢点,如果变成树梢点,添加至新一轮的循环。
        """
        
        while len(self.med_blind_alley_positions) != 0:
            # print("%%"*20)
            # 暂存节点列表
            med_blind_alley_positions = []
            for x in self.med_blind_alley_positions:
                # 新建存储列表
                pool = self.find_way_out(x)
                """  逐步建立对应的拓扑关系 """
                self.tidy_path(pool)
                # if pool[-1] in  self.crossroads_positions:
                #     print("----")
                # print(pool)
                self.links.append(pool[::-1])
                # 添加除开最后的树杈点加到已遍历点列表中
                self.med_positions = self.med_positions + pool[:-1]
                # print(self.med_positions)
                # 检测最新添加的点是否是树梢点
                x = int(pool[-1][0]/self.tile_size)
                y = int(pool[-1][1]/self.tile_size)
                # print("暂存位置:",x,y)
                # print(self.med_maze[x+1][y],self.med_maze[x-1][y],self.med_maze[x][y+1],self.med_maze[x][y-1])
                '''判断这个路口是否变成死胡同 --> 是,加到暂存点位中'''
                med = 0 
                if [(x+1)*self.tile_size,y*self.tile_size] in self.med_positions:
                    med += 1
                if [(x-1)*self.tile_size,y*self.tile_size] in self.med_positions:
                    med += 1
                if [x*self.tile_size,(y+1)*self.tile_size] in self.med_positions:
                    med += 1
                if [x*self.tile_size,(y-1)*self.tile_size] in self.med_positions:
                    med += 1  
                res = sum([self.med_maze[x+1][y],self.maze[x-1][y],self.med_maze[x][y-1],self.med_maze[x][y+1]]) + med
                # print(res,med)
                # if [10,10] in pool:
                #     print("最后的树根···")
                # 变成树梢点 --> 加入新一轮的遍历且更改循环退出条件
                if self.med_maze[x][y] == 0 and res == 3:
                    # print("#####")
                    med_blind_alley_positions.append([x*self.tile_size,y*self.tile_size])
                    self.med_crossroads_positions.remove([x*self.tile_size,y*self.tile_size])
            
            self.med_blind_alley_positions = med_blind_alley_positions

    def tidy_path(self,pos_pool):
        """ 在拆解迷宫路径的过程中进行
        - 创建列表存储pos及对应node 
        """
        pos_one = tuple(pos_pool[0])
        pos_two = tuple(pos_pool[-1])
        destination = [(self.length-1)*self.tile_size,(self.length-1)*self.tile_size]
        if destination in pos_pool:
            tf = True
        else :
            tf = False
        #  新建node
        for i in [pos_one,pos_two]:
            if i not in self.path_tree:
                self.path_tree[i] = Node(i)
        # 设置节点信息 
        self.path_tree[pos_one].set_before_node(self.path_tree[pos_two],tf)
        self.path_tree[pos_two].set_after_node(self.path_tree[pos_one])
        # 测试是否设置成功
        # print("前",self.path_tree[pos_one].pos)
        # print("前",self.path_tree[pos_two].before_node)

    def find_path(self):
        """  添加下一步该迈向的节点(栈的思想)
        - 寻找最终的路径哈
        """
        self.med_node_pos = []
        self.node_stack = [self.path_tree[(10,10)]]
        # 寻找终点所在的路径呀
        status = True 
        # flag = 0 
        destination = [(self.length-1)*self.tile_size,(self.length-1)*self.tile_size]
        while status:
            if len(self.node_stack[-1].after_node) != 0 :
                self.node_stack.append(self.node_stack[-1].after_node[0])
                pos_one = list(self.node_stack[-2].pos)
                pos_two = list(self.node_stack[-1].pos)
                for i in self.links:
                    if i[0] == pos_one and i[-1] == pos_two:
                        # print("拼接")
                        self.med_node_pos =  self.med_node_pos + i
                # 判断重点是都在列表中
                if destination in self.med_node_pos:
                    status = False
                    # print("终于找到了")
                else :
                    # pool = []
                    # for i in self.node_stack:
                    #     pool.append(i.pos)
                    # print(pool)
                    if  len(self.node_stack[-1].after_node) == 0:
                        self.node_stack.pop()
                        # 从前节点删除后节点的信息
                        self.node_stack[-1].rm_after_node()
            else: 
                # 直接删除删除该节点信息
                self.node_stack.pop()
                # flag += 1
                # if flag == 25:
                #     break
        """ 路径拼接 """
        pool = []
        for i in self.node_stack:
            pool.append(i.pos)
        m,n = 0,1
        fal_path = []
        for i in range(len(pool)-1):
            for j in self.links:
                if j[0] == list(pool[m]) and j[-1] == list(pool[n]):
                    fal_path = fal_path + j
                    m += 1
                    n += 1
        """ 截取路径 """
        number =  fal_path.index(destination)+1
        fal_path = fal_path[:number]
        """ 转换最后的路径 """
        sea = []
        for i in fal_path:
            sea.append([i[0]-10,i[1]-10])
        fal_path = sea
        return  fal_path
    
    def find_path_node(self):
        """  添加下一步该迈向的节点(栈的思想)
        - 寻找最终的路径节点
        """
        self.node_stack = [self.path_tree[(10,10)]]
        # 寻找终点所在的路径呀
        status = True 
        # flag = 0 
        while status:
            if len(self.node_stack[-1].after_node) != 0 :
                self.node_stack.append(self.node_stack[-1].after_node[0])
                if self.node_stack[-1].status:
                    status = False
                    # print("终于找到了")
                else :
                    if len(self.node_stack[-1].after_node) == 0:
                        self.node_stack.pop()
                        # 从前节点删除后节点的信息
                        self.node_stack[-1].rm_after_node()
            else: 
                # 直接删除删除该节点信息
                self.node_stack.pop()
        
    def merge_path(self):
        """ 拼接为最终的路径
        """
        pool = []
        for i in self.node_stack:
            pool.append(i.pos)
        m,n = 0,1
        fal_path = []
        for i in range(len(pool)-1):
            for j in self.links:
                if j[0] == list(pool[m]) and j[-1] == list(pool[n]):
                    fal_path = fal_path + j
                    m += 1
                    n += 1
        """ 截取路径 """
        destination = [(self.length-1)*self.tile_size,(self.length-1)*self.tile_size]
        number =  fal_path.index(destination)+1
        fal_path = fal_path[:number]
        """ 转换最后的路径 """
        sea = []
        for i in fal_path:
            sea.append([i[0]-10,i[1]-10])
        fal_path = sea
        return  fal_path

    def merge_fal_path(self,path_nodes):
        """ 拼接为最终的路径
        """
        pool = []
        for i in path_nodes:
            pool.append(i.pos)
        m,n = 0,1
        fal_path = []
        for i in range(len(pool)-1):
            for j in self.links:
                if j[0] == list(pool[m]) and j[-1] == list(pool[n]):
                    fal_path = fal_path + j
                    m += 1
                    n += 1
        """ 截取路径 """
        destination = [(self.length-1)*self.tile_size,(self.length-1)*self.tile_size]
        number =  fal_path.index(destination)+1
        fal_path = fal_path[:number]
        """ 转换最后的路径 """
        sea = []
        for i in fal_path:
            sea.append([i[0]-10,i[1]-10])
        fal_path = sea
        return  fal_path

    def all(self):
        """ 教学目标 
        """
        # 寻找节点 
        self.find_path_node()
        # 拼接路径
        path = self.merge_path()
        
        return path

    def root_node(self):
        """ 返回根节点
        """
        return  self.path_tree[(10,10)]


class Maze_tool():

    """ 迷宫破解工具 """

    def __init__(self,length):
        """ 初始构造函数 """
        self.maze = None
        self.position = [1,1]
        self.tile_size = 10
        self.length = length

    def is_end(self,postion):
        """ 判断输入的位置是不是出口 
        """
        status = False
        if  postion == [self.length-2,self.length-2]:
            # print("判断:",[self.length-2,self.length-2],postion) 
            status = True
        return status

    def detection(self,maze,position):
        """ 探测所处位置周围的道路及终点判断
        """
        self.maze = maze
        # 判断是否到达终点
        if self.is_end(position):
            return "END"
        # 路径标记为0的左边点
        pos_pool = [
            [position[0]-1,position[1]],
            [position[0],position[1]-1],
            [position[0]+1,position[1]],
            [position[0],position[1]+1],
        ]
        med_result = []
        
        # 判断不为墙的位置
        result = []
        for pos in pos_pool:
            if self.maze[pos[0]][pos[1]] != 1:
                result.append(pos)

        # 索引对应的状态值
        tag_pool = [self.maze[pos[0]][pos[1]] for pos in result]
        check_tag = list(set(tag_pool))
        
        # 周围节点判断
        if  (0 in tag_pool and 2 in tag_pool and len(check_tag) == 2) or (0 in tag_pool and  len(check_tag) == 1) or (0 in tag_pool and 3 in tag_pool and len(check_tag) == 2):
            med_result = []
            for pos in pos_pool:
                if self.maze[pos[0]][pos[1]] == 0:
                    med_result.append(pos)
            med_result.insert(0,0)
            # print("0",med_result[1])
            
        if (2 in tag_pool and 4 in tag_pool and len(check_tag) == 2) or (2 in tag_pool and len(check_tag) == 1):
            med_result = []
            for pos in pos_pool:
                if self.maze[pos[0]][pos[1]] == 2:
                    med_result.append(pos)
            med_result.insert(0,2)
            # print("2",med_result[1])

        if 2 in tag_pool and 0 in tag_pool and 4 in tag_pool and len(check_tag) == 3:
            med_result = []
            for pos in pos_pool:
                if self.maze[pos[0]][pos[1]] == 0:
                    med_result.append(pos)
            med_result.insert(0,3)
            # print("3",med_result[1])
            
        if  3 in tag_pool and 4 in tag_pool and len(check_tag) == 2:
            med_result = []
            for pos in pos_pool:
                if self.maze[pos[0]][pos[1]] == 3:
                    med_result.append(pos)
            med_result.insert(0,4)
            # print("4",med_result[1])
        # print(maze)
        # print("返回值:",med_result)
        return med_result

    def find_neighbours(self,position,maze):
        """ 寻找邻近可以行进的点
        """
        self.maze = maze
        neighbours = []
        #Look for open cells
        if (position[1]-1) > 0:
            if self.maze[position[0]][position[1]-1] in (FLOOR, EXIT): #Above
                neighbours.append([position[0],position[1]-1])

        if (position[0]-1) > 0:
            if self.maze[position[0]-1][position[1]] in (FLOOR, EXIT): #Left
                neighbours.append([position[0]-1,position[1]])

        if (position[0]+1) < self.length-1:

            if self.maze[position[0]+1][position[1]] in (FLOOR, EXIT): #Right
                neighbours.append([position[0]+1,position[1]])

        if (position[1]+1) < self.length-1:
            if self.maze[position[0]][position[1]+1] in (FLOOR, EXIT): #Down
                neighbours.append([position[0],position[1]+1])

        return neighbours