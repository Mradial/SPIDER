
import pygame 
import  maze
import sys
import central_
import  copy 

width_cells = 21
height_cells = 21
tile_size = 10

# 初始化设置
pygame.init()


fclock =  pygame.time.Clock()

""" 屏幕创建及 """
# 创建主屏幕
screen = pygame.display.set_mode((800,600))
map_screen= pygame.surface.Surface((width_cells*tile_size, height_cells*tile_size))
main_screen = pygame.surface.Surface((600,600))

# 设置标题 
pygame.display.set_caption('Maze_Path')

""" 生成迷宫,控制中心,玩家, 动态绘制类 """
# 生成新的迷宫 绘制也是这里面
new_maze = maze.Maze(tile_size, map_screen)
layout_one = copy.deepcopy(new_maze.layout)
layout_two = copy.deepcopy(new_maze.layout)

# 创建控制中心
control = central_.Center(new_maze.layout,tile_size)
player =  central_.Player()

# 创建绘制类
draw_maze = central_.CreateMaze(layout_two,width_cells) 
draw_maze.build_topology()

# 初始速度 
speed = [0,0]
direction = 1

''' 作业代码 '''

now_position = [1,1]
layout = copy.deepcopy(new_maze.layout)

def control_pos(speed,maze,position):
    m =  position[0] + speed[0]
    n =  position[1] + speed[1]
    # 进入核心判断
    if maze[m][n] == 1:
        pass
    else:
        position = [m,n]
    return position

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                speed = [1,0]
                direction = 1
            if event.key == pygame.K_LEFT:
                speed = [-1,0]
                direction = 3
            if event.key == pygame.K_UP:
                speed = [0,-1]
                direction = 4
            if event.key == pygame.K_DOWN:
                speed = [0,1]
                direction = 2
            # 控制移动
            control.control_rect(speed)
            now_position = control_pos(speed,layout,now_position)
            # draw_maze.draw_neighbor(main_screen,control.map_position,tile_size)
            speed = [0,0]
    
    # 绘制背景
    screen.fill((0,0,0))
    
    # 游戏角色切换造型
    player.move(direction,main_screen)
    
    # 绘制迷宫地图啊 
    control.draw_map_maze(map_screen)
    
    # 实际场景绘制
    # print(now_position,control.map_position)
    # print(control.key_positions)
    draw_maze.draw_neighbor(main_screen,now_position,tile_size,control.key_positions)
    # 绘制角色
    main_screen.blit(player.image,player.rect)

    
    # 检测键盘输入
    screen.blit(map_screen,(590,0))
    screen.blit(main_screen,(-10,0))
    
    # 显示游戏结果信息
    control.show_info(screen)
    
    pygame.display.update()
    fclock.tick(30)