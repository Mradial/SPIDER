#  知识点拆解

## 8-1 迷宫寻宝 

### 核心代码

```python
now_position = [1,1]
layout = copy.deepcopy(new_maze.layout)

def control_pos(speed,maze,position):
    m =  position[0] + speed[0]
    n =  position[1] + speed[1]
    # 进入核心判断
    if maze[m][n] == 1:
        pass
    else:
        position = [m,n]
    return position
```




#### 1. 迷宫的实现基本原理

* 列表 -- > 迷宫

![](https://uploader.shimo.im/f/WP7xZLezufM3UXBL.png!thumbnail)



#### 2. 游戏规则讲解

* 只有找到三个宝箱才能通关哦 --> 打来最终大门的钥匙

![](https://uploader.shimo.im/f/oLdqp0Ptf6csEZiV.png!thumbnail)




## 8-2 穿过迷宫


### 代码

```python

layout = copy.deepcopy(new_maze.layout)
tool = central_.Maze_tool(21)
now_position = [1,1]

# 栈
stack = []
def maze_solve(position,layout):
    global stack
    global now_position
    x = position[0]
    y = position[1]
    neighbours = []
    if layout[x][y] == 0:
        layout[x][y] = 2
    elif layout[x][y] == 4:
        return "END"
    # 使用提供的函数,探索周围的路
    neighbours = tool.find_neighbours(position,layout)
    
    # 判断周围是否存在可以前进的路
    if neighbours:
        new_position = neighbours[0]
        stack.append(position)
        position = new_position
    else:
        if stack:
            position = stack.pop() 
    
    now_position =  position
```

#### 1、 游戏规则讲解


**以最快的的速度穿过找到通往迷宫终点的路径,并在快速上通过。（在规定时间内通过）**