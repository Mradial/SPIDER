import pygame 
import central_
import  copy 



# 初始化设置
pygame.init()
fclock =  pygame.time.Clock()
screen = pygame.display.set_mode((800,600))
pygame.display.set_caption('Maze_Path')


adventure = central_.Adventure(screen)
adventure.create()


# 初始方向
direction = 1

# 创建迷宫
maze = adventure.get_maze()


now_position = [1, 1]

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

        ''' 作业代码 '''

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                m = now_position[0] + 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_LEFT:
                m = now_position[0] - 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_UP:
                m = now_position[0]
                n = now_position[1] - 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_DOWN:
                m = now_position[0]
                n = now_position[1] + 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]


        # 控制人物朝向
        if event.type == pygame.KEYDOWN:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    adventure.control.change_direction("右")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_LEFT:
                    adventure.control.change_direction("左")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_UP:
                    adventure.control.change_direction("上")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_DOWN:
                    adventure.control.change_direction("下")
                    adventure.control.control_rect(now_position)
            
    
    # 绘制背景
    screen.fill((0, 0, 0))
    # 终极绘制
    adventure.fal_draw(now_position)
    
    
    pygame.display.update()
    fclock.tick(30)