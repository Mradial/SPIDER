import pygame 
import central_
import  copy 

# 初始化设置
pygame.init()

fclock =  pygame.time.Clock()

""" 屏幕创建及 """
# 创建主屏幕
screen = pygame.display.set_mode((800,600))
pygame.display.set_caption('Maze_Path')

# 这是冒险吗？？ 
adventure = central_.Adventure(screen)
adventure.create()


now_position = [1,1]
# 初始方向
direction = 1

# 创建迷宫
maze = adventure.get_maze()
layout = adventure.get_maze()

tool = central_.Maze_tool(21)

stack_position = [1,1] 
stack = []
def maze_solve(position,layout):
    global stack
    global stack_position
    
    neighbours = []
    if layout[position[0]][position[1]] == 0:
        layout[position[0]][position[1]] = 2
    elif layout[position[0]][position[1]] == 4:
        return "END"
    neighbours = tool.find_neighbours(position,layout)
    if neighbours:
        new_position = neighbours[0]
        stack.append(position)
        position = new_position
    else:
        if stack:
            position = stack.pop() 
    stack_position =  position

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

        ''' 作业代码 '''

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                m = now_position[0] + 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_LEFT:
                m = now_position[0] - 1
                n = now_position[1]
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_UP:
                m = now_position[0]
                n = now_position[1] - 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

            if event.key == pygame.K_DOWN:
                m = now_position[0]
                n = now_position[1] + 1
                if maze[m][n] == 1:
                    pass
                else:
                    now_position = [m, n]

        # 控制人物朝向
        if event.type == pygame.KEYDOWN:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    adventure.control.change_direction("右")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_LEFT:
                    adventure.control.change_direction("左")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_UP:
                    adventure.control.change_direction("上")
                    adventure.control.control_rect(now_position)

                if event.key == pygame.K_DOWN:
                    adventure.control.change_direction("下")
                    adventure.control.control_rect(now_position)
            
    
    # 绘制背景
    screen.fill((0, 0, 0))
    """ 寻找最终的路径 """
    maze_solve(stack_position,layout)
    adventure.draw_path(stack)
    # 终极绘制
    adventure.fal_draw(now_position)  
    
    pygame.display.update()
    fclock.tick(5)