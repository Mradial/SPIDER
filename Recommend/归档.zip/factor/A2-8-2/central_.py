import pygame
import random
import sys
import copy 


pygame.init()

""" 资源加载 """
apple = pygame.transform.rotozoom(pygame.image.load("media/image/path.png"),0,0.4)
boom = pygame.transform.rotozoom(pygame.image.load("media/image/wall.png"),0,0.5)
peach = pygame.transform.rotozoom(pygame.image.load("media/image/peach.png"),0,0.4)

# 游戏效果加载
happy = pygame.image.load('media/image/happy.png')

# 字体加载
font = pygame.font.Font('./font/HanyiSentyCrayon.ttf', 80)



""" 随机迷宫生成 """

# 矩阵颜色的对应值
FLOOR = 0
WALL  = 1
PATH  = 2
REPETITION = 3
EXIT = 4
SOLUTION = 5


# 迷宫背景颜色 --> 白色
FLOOR_COLOUR = (255,255,255)
# 迷宫墙壁 --> 黑色
WALL_COLOUR = (0,0,0)
# 迷宫路径颜色 --> 绿色
PATH_COLOUR = (0,255,0)
# 迷宫解法路径颜色  --> 红色
SOLVER_COLOUR = (255,0,0)
# 走过两次的路径
REPETITION_COLOR = (0,0,255)
# 出口为金色
EXIT_COLOR = (255,251,0)
# 最后的通路颜色--->黄色
SOLUTION_COLOR = (0,255,255)

# [背景、墙壁、行走路径]
MAZE_COLOURS = [FLOOR_COLOUR, WALL_COLOUR, PATH_COLOUR, REPETITION_COLOR, EXIT_COLOR, SOLUTION_COLOR]

# 生成迷宫矩阵
def mazeArray(value, width, height):
    return [[value]*height for i in range(width)]

# 返回4值元组
def cellRect(x, y, tile_size):
    return (x*tile_size, y*tile_size, tile_size, tile_size)


class Maze():

    """ 随机迷宫生成 """

    def __init__(self,tile_size, screen):
        """ 迷宫构造函数 
        """
        self.width = 20
        self.height = 20
        self.tile_size = tile_size
        # 列表初始化函数
        WALL =  1
        self.layout = mazeArray(WALL, self.width, self.height)
        FLOOR = 0
        self.visited = mazeArray(FLOOR,self.width, self.height)
        # 绘制屏幕
        self.screen = screen
        self.neighbours = []
        self.stack = []
        self.x = 0
        self.y = 0
        self.generate()
        self.maze = self.maze_layout()
        

    def Regenerate(self):
        """  内部初始化变量 
        """
        self.__init__(self.width, self.height, self.tile_size, self.screen)
    
    def ClearPath(self):
        """ 清除路径
        """
        for i in range(self.width):
            for j in range(self.height):
                # PATH = 2 -->  FLOOR = 0
                # 数值替换即颜色替换
                if self.layout[i][j] in (PATH, REPETITION):
                    self.layout[i][j] = FLOOR
    
    # def draw_self(self):
    #     """ 绘制迷宫本身 
    #     """
    #     for i in range(self.width):
    #         for j in range(self.height):
    #             # 循环提取矩阵cell值
    #             cell_type = self.layout[i][j]
    #             # 绘制对应的颜色
    #             self.screen.fill(MAZE_COLOURS[cell_type], cellRect(i, j, self.tile_size))
         
    def generate(self):
        """ 生成主循环函数 """
        while not self._generate_step():
            pass
        # 执行结束
        self.status = False
   
    def _generate_step(self):
        """ 迷宫生成主体函数 
        """
        # 从迷宫的墙中获得一个格子，把它设置到迷宫中
        self.layout[self.x][self.y] = FLOOR
        # 设置迷宫出口
        self.layout[self.width-2][self.height-2] = EXIT
        #把当前位置标记为已经访问
        
        self.visited[self.x][self.y] = True
        self.neighbours = [] #Reset neighbours

        #寻找没有初始化过的迷宫道路
        
        # 向上探索，有没有未被初始化的迷宫路面
        if (self.y-2) >= 0:
            if not self.visited[self.x][self.y-2]: 
                self.neighbours.append((self.x,self.y-2))
        # 向左探索
        if (self.x-2) >= 0:
            if not self.visited[self.x-2][self.y]: 
                self.neighbours.append((self.x-2,self.y))
        # 向右探索
        if (self.x+2) < self.width:
            if not self.visited[self.x+2][self.y]: 
                self.neighbours.append((self.x+2,self.y))
        # 向下探索
        if (self.y+2) < self.height:
            if not self.visited[self.x][self.y+2]: 
                self.neighbours.append((self.x,self.y+2))

        if self.neighbours:
            # print(self.neighbours)
            #随机从相邻块列表中选择一个格子
            newCell = random.choice(self.neighbours)
            #Add current cell to the stack
            # 将当前的位置存储在列表中
            self.stack.append((self.x,self.y))

            #Remove the wall between current and chosen cell
            # 选择随机选中的cell
            new_x, new_y = newCell

            #Cell is above
            if new_x == self.x and (new_y+2) == self.y:
                self.layout[new_x][new_y+1] = FLOOR
            #Cell is below
            elif new_x == self.x and (new_y-2) == self.y:
                self.layout[new_x][new_y-1] = FLOOR
            #Cell is left
            elif (new_x+2) == self.x and new_y == self.y:
                self.layout[new_x+1][new_y] = FLOOR
            #Cell is right
            elif (new_x-2) == self.x and new_y == self.y:
                self.layout[new_x-1][new_y] = FLOOR

            self.x = new_x
            self.y = new_y
        else: #Cell has no neighbours
            if self.stack:
                #Go back to the previous current cell
                self.x, self.y = self.stack.pop()

            if not self.stack:
                #Generation has finished
                return True

    def maze_layout(self):
        """ 给矩阵加边
        """
        maze = self.layout
        maze.insert(0,[1 for i in range(self.width)])
        med_pool = []
        for row in maze:
            row.insert(0,1)
            med_pool.append(row)
        return med_pool

    # def draw_maze(self,screen):
    #     """ 绘制迷宫本身 
    #     """
    #     for i in range(self.width):
    #         for j in range(self.height):
    #             # 循环提取矩阵cell值
    #             cell_type = self.maze[i][j]
    #             # 绘制对应的颜色

    #             screen.fill(MAZE_COLOURS[cell_type], cellRect(i, j, self.tile_size))



class Player():
    
    """ 玩家造型切换 """

    def __init__(self):
        """ 玩家构造函数 
        """
        self.rightimage = [pygame.image.load("media/player/links_01.png"),pygame.image.load("media/player/links_02.gif"),pygame.image.load("media/player/links_03.gif"),pygame.image.load("media/player/links_04.gif"),pygame.image.load("media/player/links_05.gif"),pygame.image.load("media/player/links_06.gif"),pygame.image.load("media/player/links_07.gif"),pygame.image.load("media/player/links_08.gif")]
        self.downimage = [pygame.image.load("media/player/links_09.gif"),pygame.image.load("media/player/links_10.gif"),pygame.image.load("media/player/links_11.gif"),pygame.image.load("media/player/links_12.gif"),pygame.image.load("media/player/links_13.gif"),pygame.image.load("media/player/links_14.gif"),pygame.image.load("media/player/links_15.gif"),pygame.image.load("media/player/links_16.gif")]
        self.leftimage = [pygame.image.load("media/player/links_17.gif"),pygame.image.load("media/player/links_18.gif"),pygame.image.load("media/player/links_19.gif"),pygame.image.load("media/player/links_20.gif"),pygame.image.load("media/player/links_21.gif"),pygame.image.load("media/player/links_22.gif"),pygame.image.load("media/player/links_23.gif"),pygame.image.load("media/player/links_24.gif")]
        self.upimage = [pygame.image.load("media/player/links_25.gif"),pygame.image.load("media/player/links_26.gif"),pygame.image.load("media/player/links_27.gif"),pygame.image.load("media/player/links_28.gif"),pygame.image.load("media/player/links_29.gif"),pygame.image.load("media/player/links_30.gif"),pygame.image.load("media/player/links_31.gif"),pygame.image.load("media/player/links_32.gif")]
        self.image = pygame.image.load("media/player/links_01.png")
        self.rect = self.image.get_rect()
        self.rect.center = [160, 150]
        self.flag = 0

    def move(self,direction,screen):
        """ 角色移动控制
        """
        self.flag += 1
        flag = self.flag%8
        # move the skier right and left
        if direction == 1:
            self.image = pygame.transform.rotozoom(self.rightimage[flag],0,0.3)
        elif direction == 2:
            self.image = pygame.transform.rotozoom(self.downimage[flag],0,0.3)
        elif direction == 3:
            self.image = pygame.transform.rotozoom(self.leftimage[flag],0,0.3)
        else:
            self.image = pygame.transform.rotozoom(self.upimage[flag],0,0.3)
        # 角色屏幕绘制
        screen.blit(self.image,self.rect)


class Center():

    """ 迷宫控制核心 """

    def __init__(self,maze,tile_size):
        # 初始化传入生成好的迷宫矩阵
        self.maze = maze
        self.size = len(maze)
        # tile_size
        self.tile_size = tile_size
        # 记录按键事件（之前与现在）
        self.key = None
        # map 位置 
        self.map_position = [tile_size,tile_size]
        self.map_rect = pygame.Rect(tile_size,tile_size,self.tile_size,self.tile_size)
        # 获取迷宫的死胡同点
        self.blind_alley_positions = self.get_blind_alley_positions()
        # 钥匙埋藏点
        self.key_positions = []
        # 收集的钥匙数量 
        self.key_number = 0
        # 游戏运行状态
        self.font = font
        self.game_status = True
        # 走过的路径
        self.path = [[tile_size,tile_size]]
        self.real_path = 1
        # 游戏通关耗时
        self.time = 0
        self.direction_speed = {
            1:[self.tile_size,0],
            2:[0,self.tile_size],
            3:[-self.tile_size,0],
            4:[0,-self.tile_size],
        }
        self.direction = 1
      
    def control_rect(self,position):
        """
        控制小地图上的角色移动
        - 输入: speed 
        - 输出: 更改对应属性:
        """
        m =  position[0]
        n =  position[1]
        self.map_position = [m*self.tile_size,n*self.tile_size]
        self.map_rect =  pygame.Rect(self.map_position[0],self.map_position[1],self.tile_size,self.tile_size)
        
              
    def move(self,speed):
        """ 移动判断集合 """
        self.control_rect(speed)
        
    def get_blind_alley_positions(self):
        """ 获取迷宫死胡同点
        """
        blind_alley_positions = []
        for m,n in  enumerate(self.maze):
            for x,y in enumerate(n):
                # 生成迷宫右下边为1
                if m < self.size-1 and x < self.size-1 and m > 0 and x > 0 :
                    res = sum([self.maze[m+1][x],self.maze[m-1][x],self.maze[m][x-1],self.maze[m][x+1]])
                    # 死胡同判断
                    if y == 0 and res == 3 :
                        if  m == 1 and x == 1:
                            pass
                        else:
                            blind_alley_positions.append([m*self.tile_size,x*self.tile_size])
        return blind_alley_positions

    def draw_key(self,screen):
        """ 随机选取死胡同点放置"三个Key"
        - 随机选取三死胡同点藏Key,并在小地图上绘制对应的点
        - 输入:绘制的屏幕
        """
        #  选取藏钥匙的地点
        if len(self.key_positions) == 0 and self.key_number == 0:
            key_positions = []
            for i in range(3):
            # while len(self.key_positions) < 4:
                key = random.choice(self.blind_alley_positions)
                key_positions.append(key)
                self.blind_alley_positions.remove(key)
            self.key_positions = key_positions
        # 在对应的位置进行绘制
        if len(self.key_positions) != 0:
            for x in self.key_positions:
                # 钥匙绘制
                pygame.draw.rect(screen,(255,0,100),pygame.Rect(x[0],x[1],self.tile_size,self.tile_size))
        
        # 判断自己是否走到这个位置上,如果在收集成功
        if self.map_position in self.key_positions:
            self.key_number += 1
            self.key_positions.remove(self.map_position)
    
    def pass_game(self):
        """ 判断游戏是否通关 
        - 钥匙数量收集完成后且位置位于终点坐标 --> 游戏过关
        - 输出: bool值
        """
        if self.map_position == [(self.size-2)*self.tile_size,((self.size-2))*self.tile_size]:
            get_time = pygame.time.get_ticks()//1000
            self.game_status = False

            
    def show_info(self,screen):
        """ 绘制游戏通关时间,走的步数
        -  绘制到对应的区域
        """
        if self.game_status:
            self.time = pygame.time.get_ticks()//1000
        # 游戏概况
        time_bar = self.font.render("用时:"+str(self.time), True,(255,255,0))
        # step_bar = self.font.render("步数:" + str(self.real_path), True,(255,255,0))
        # real_step = self.font.render("实际:" + str(len(self.path)), True,(255,255,0))
        # 游戏信息绘制
        screen.blit(time_bar,(600,250))
        # screen.blit(step_bar,(600,300))
        # screen.blit(real_step,(600,350))

    def draw_path(self,screen):
        """ 绘制行走的路线
        - 绘制路线
        """
        if self.map_position != self.path[-1]:
            self.real_path += 1
            if self.map_position not in self.path:
                self.path.append(self.map_position)
            else:
                self.path.pop()
        # 进行路径绘制
        for  i in self.path:
            pygame.draw.rect(screen,(0,100,0),pygame.Rect(i[0],i[1],self.tile_size,self.tile_size))  

    def draw_fal_path(self,path,screen):
        """ 绘制深度优先的路径
        ——  最终的路径绘制
        """
        # 进行路径绘制
        for  i in path:
            pygame.draw.rect(screen,(255,128,128),pygame.Rect(i[0]*self.tile_size,i[1]*self.tile_size,self.tile_size,self.tile_size)) 
    
    def change_direction(self,direction):
        """ 获取键盘事件并更改对应的操作
        """
        if direction == "右" :
            self.direction = 1
        if direction == "左":
            self.direction = 3
        if direction == "上" :
            self.direction = 4
        if direction == "下":
            self.direction = 2


    def draw_map_maze(self,screen):
        """ 绘制迷宫本身
        """
        for i in range(self.size):
            for j in range(self.size):
                # 循环提取矩阵cell值
                cell_type = self.maze[i][j]
                # 绘制对应的颜色
                screen.fill(MAZE_COLOURS[cell_type], pygame.Rect(i*self.tile_size, j*self.tile_size, self.tile_size,self.tile_size))
        # 绘制方块
        pygame.draw.rect(screen,(0,255,0),self.map_rect)
        # 绘制钥匙
        # self.draw_key(screen)
        # 判断游戏是否过关
        self.pass_game()
        # 绘制最终的路径
        # self.draw_fal_path(stack,screen)
        # self.draw_path(screen)
        # keys = pygame.key.get_pressed()
        # if keys[pygame.K_SPACE]:
        #     pass 
        # else:
        #     screen.fill((0,0,0))
        # 绘制游戏终止条件
        


class  Cell():

    """ 真实位置的绘图单元 """

    def __init__(self,id,image):
        """ 绘制单元的构造函数
        """
        # 主键
        self.id = id
        # cell 文件属性 
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (0,0)
        # 维护自身的拓扑关系图
        self.right = None
        self.right_up = None
        self.up = None
        self.left_up = None
        self.left = None
        self.left_down = None
        self.down = None
        self.right_down = None
    
    def set_image(self,image):
        """ 设置cell的图片属性
        """
        self.image = image 

    def set_neighbor(self,neighbor_pool):
        """ 设置自己邻近cell (逆时针旋转)
        """
        self.right = neighbor_pool[0]
        self.right_up = neighbor_pool[1]
        self.up = neighbor_pool[2]
        self.left_up = neighbor_pool[3]
        self.left = neighbor_pool[4]
        self.left_down = neighbor_pool[5]
        self.down = neighbor_pool[6]
        self.right_down = neighbor_pool[7]

    def get_neighbor(self):
        """  返回自己的邻近cell （共计8个元素）
        """
        cells = [self.left_up,self.up,self.right_up,
                self.left,self.right,
                self.left_down,self.down,self.right_down]
        return cells 

    def set_image_rect(self,pos_):
        """  设置图片的Rect.center
        """
        self.rect.center = pos_


class CreateMaze():

    """ 真实的迷宫绘制  """

    def __init__(self,layout,tile_size,screen):
        """ 迷宫构造函数绘制方式
        """
        # 迷宫矩阵
        self.maze = layout
        self.new_maze = []
        # 原始迷宫尺寸
        self.size = len(layout)
        # 基础素材列表
        self.atom_pool = [apple,boom,peach]
        # 绘制屏幕
        self.screen = screen
        # 墙体尺寸
        self.tile_size = tile_size

    def add_zero(self):
        """ 原始迷宫双边加零 + 实例化
        """ 
        lake = self.maze
        # 上下加边
        lake.insert(0,[2 for i in range(self.size+1)])
        lake.append([2 for i in range(self.size+1)])
        # 加边
        # lake.insert(0,[2 for i in range(self.size+1)])
        # lake.append([2 for i in range(self.size+1)])
        # 循环首尾加减
        sea = []
        for row in lake:
            row.insert(0,2)
            row.append(2)
            #再加边
            # row.insert(0,2)
            # row.append(2)
            sea.append(row)
        self.new_maze = sea

    def build_topology(self):
        """构建拓扑关系
        - 矩阵颜色的对应值
        """
        # 加零操作
        self.add_zero()
        
        # 列表存储实例化对象
        maze_obj = []
        for x in self.new_maze:
            pool = []
            for y in x:
                if y == 1 or y == 2:
                    # 墙
                    cell = Cell(y,self.atom_pool[1])
                elif y == 0:
                    # 路径
                    cell = Cell(y,self.atom_pool[0])
                elif y == 4:
                    cell = Cell(y,self.atom_pool[2])
                else:
                    cell = Cell(y,self.atom_pool[2])
                pool.append(cell)
            maze_obj.append(pool)
        self.new_maze = maze_obj
        # 构建拓扑关系
        for m,n in enumerate(self.new_maze):
            # 下边框不构建
            for x,y in enumerate(n):
                    # 上 左边框不构建
                if y.id != -1:
                    try:
                        # 拓扑关系开始建立
                        pool = [
                            self.new_maze[m][x+1],
                            self.new_maze[m-1][x+1],
                            self.new_maze[m-1][x],
                            self.new_maze[m-1][x-1],
                            self.new_maze[m][x-1],
                            self.new_maze[m+1][x-1],
                            self.new_maze[m+1][x],
                            self.new_maze[m+1][x+1],
                        ]
                        y.set_neighbor(pool)
                    except IndexError :
                        pass     

    def draw_neighbor(self,map_position):
        """ 根据坐标判断邻居元素 并进行绘制 
        """
        map_position = [map_position[0]*10,map_position[1]*10]
        x,y = int(map_position[0]/10)+1,int(map_position[1]/10)+1
        # 找到对应元素的位置  
        cell = self.new_maze[x][y]

        cells_pool = [
            [cell.left_up.left_up, cell.left_up.up, cell.up.up, cell.right_up.up, cell.right_up.right_up],
            [cell.left_up.left, cell.left_up, cell.up, cell.right_up, cell.right_up.right],
            [cell.left.left, cell.left, cell, cell.right, cell.right.right],
            [cell.left_down.left, cell.left_down, cell.down, cell.right_down, cell.right_down.right],
            [cell.left_down.left_down, cell.left_down.down, cell.down.down, cell.right_down.down, cell.right_down.right_down]]

        # 设置绘制位置,然后接着绘制
        self.screen.fill((255,255,255))
        for m,n in enumerate(cells_pool):
            e = m * 50 + 25
            for x,y in enumerate(n):
                f = x * 50 + 25
                y.set_image_rect((e,f))
                self.screen.blit(y.image,y.rect)
        
        ''' 内部函数调用 '''
        # 绘制KEY
        # self.draw_key(key_positions,map_position)
        
    def draw_key(self,key_positions,map_position):
        """ 在实景中绘制真的Key图案
        - 判断为key位置是否可以绘制的问题
        - 输入: map_position,key_positions
        """
        map_position = [map_position[0]*10,map_position[1]*10]
        if len(key_positions) != 0 :
            # 钥匙坑位置存在时，才判断是否绘制
            for i in key_positions:
                if  abs(map_position[0]-i[0]) <= 20 and abs(map_position[1]-i[1]) <= 20:
                    x = 300 - (map_position[0]-i[0]) * 12
                    y = 300 - (map_position[1]-i[1]) * 12
                    # 图形绘制问题的哈
                    rect = pygame.Rect(x,y,40,40)
                    rect.center = (x,y) 
                    pygame.draw.rect(self.screen,(255,0,100),rect)


class Maze_tool():

    """ 迷宫破解工具 """

    def __init__(self,length):
        """ 初始构造函数 """
        self.maze = None
        self.position = [1,1]
        self.tile_size = 10
        self.length = length

    def find_neighbours(self,position,maze):
        """ 寻找邻近可以行进的点
        """
        self.maze = maze
        neighbours = []
        #Look for open cells
        if (position[1]-1) > 0:
            if self.maze[position[0]][position[1]-1] in (FLOOR, EXIT): #Above
                neighbours.append([position[0],position[1]-1])

        if (position[0]-1) > 0:
            if self.maze[position[0]-1][position[1]] in (FLOOR, EXIT): #Left
                neighbours.append([position[0]-1,position[1]])

        if (position[0]+1) < self.length-1:

            if self.maze[position[0]+1][position[1]] in (FLOOR, EXIT): #Right
                neighbours.append([position[0]+1,position[1]])

        if (position[1]+1) < self.length-1:
            if self.maze[position[0]][position[1]+1] in (FLOOR, EXIT): #Down
                neighbours.append([position[0],position[1]+1])

        return neighbours


class Adventure():

    """ 这是在冒险吗 """
    
    def __init__(self,screen):
        """ 构造函数 """
        # self.map_screen = None
        # self.main_screen = None
        self.screen = screen
        # 迷宫矩阵的初始尺寸
        self.width_cells = 21
        self.height_cells = 21
        self.tile_size = 25
        self.main_cell_size = 50
        # 绘制区域
        self.map_screen = pygame.surface.Surface((self.width_cells*self.tile_size, self.height_cells*self.tile_size))
        self.main_screen = pygame.surface.Surface((5*self.main_cell_size,5*self.main_cell_size))
        # 不同状态的绘制位置
        self.map_positions = (0,0)
        self.main_positions = (550,0)
        # 迷宫原始矩阵
        self.maze = self.create_maze()
        self.layout_one = copy.deepcopy(self.maze.layout)
        self.layout_two = copy.deepcopy(self.maze.layout)
        self.control = None
        self.player = None
        self.draw_maze = None

    def change_screen(self):
        """ 修改对应的屏幕尺寸 """
        self.tile_size = 25
        self.main_cell_size = 50
        self.map_positions = (0,0)
        self.main_positions = (550,0)
        self.map_screen = pygame.surface.Surface((self.width_cells*self.tile_size, self.height_cells*self.tile_size))
        self.main_screen = pygame.surface.Surface((5*self.main_cell_size,5*self.main_cell_size))
        
    def create_maze(self):
        """ 生成迷宫(迷宫实例化) """
        # 生成迷宫并返回迷宫本身矩阵
        new_maze = Maze(self.tile_size, self.map_screen)
        return new_maze
    
    def get_maze(self):
        """ 获取迷宫的绘制矩阵"""
        # 获取迷宫的矩阵(原始0-1)
        return copy.deepcopy(self.maze.layout)

    def create(self):
        """ 创建控制中心、角色及迷宫绘制类 """
        self.control = Center(self.layout_one,self.tile_size)
        self.player = Player()
        self.draw_maze = CreateMaze(self.layout_two,self.tile_size,self.main_screen) 
        # 建构图形的拓扑关系
        self.draw_maze.build_topology()

    def fal_draw(self,now_position):
        """ 最后的绘制 """

        # 绘制迷宫地图
        self.screen.blit(self.map_screen,(0,0))
        self.screen.blit(self.main_screen,(550,0))

        # 绘制地图
        self.control.draw_map_maze(self.map_screen)
        # 绘制迷宫
        self.draw_maze.draw_neighbor(now_position)
        # 绘制迷宫中的宝物
        self.draw_maze.draw_key(self.control.key_positions,now_position)
        # 绘制角色
        self.player.move(self.control.direction, self.main_screen)
        self.main_screen.blit(self.player.image,self.player.rect)
        # 显示游戏结果信息
        self.control.show_info(self.screen)
        
        if not self.control.game_status:
            self.screen.fill((255,255,255))
            self.screen.blit(happy,(100,100))

    def draw_path(self,stack):
        """ 绘制探测路径 """
        self.control.draw_fal_path(stack,self.map_screen)
        pygame.draw.rect(self.map_screen,(0,255,0),self.control.map_rect)
